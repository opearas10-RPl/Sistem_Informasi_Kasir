<h1>Input Data Produk</h1>

<p>Isi data produk lalu simpan.</p>

@if ($errors->any())
    <ul>
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
@endif

<form method="POST" action="/produk">
    @csrf

    <div>
        <label>Kode Produk</label>
        <br>
        <input
            type="text"
            name="kode_produk"
            value="{{ old('kode_produk') }}"
            required
        >
    </div>

    <br>

    <div>
        <label>Nama Produk</label>
        <br>
        <input
            type="text"
            name="nama_produk"
            value="{{ old('nama_produk') }}"
            required
        >
    </div>

    <br>

    <div>
        <label>Kategori</label>
        <br>
        <input
            type="text"
            name="kategori"
            value="{{ old('kategori') }}"
        >
    </div>

    <br>

    <div>
        <label>Harga</label>
        <br>
        <input
            type="number"
            name="harga"
            min="0"
            value="{{ old('harga') }}"
            required
        >
    </div>

    <br>

    <div>
        <label>Stok</label>
        <br>
        <input
            type="number"
            name="stok"
            min="0"
            value="{{ old('stok', 0) }}"
            required
        >
    </div>

    <br>

    <a href="/produk">Batal</a>
    <button type="submit">Simpan</button>
</form>


