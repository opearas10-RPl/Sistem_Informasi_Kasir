<h1>Dashboard</h1>

<p>Selamat datang di Sistem Informasi Kasir.</p>

<hr>

<h3>Informasi Produk</h3>

<table border="1" cellpadding="8">  
    <tr>
        <th>Jumlah Produk</th>
        <th>Total Stok</th>
    </tr>
    <tr>
        <td>{{ $totalProduk }}</td>
        <td>{{ $totalStok }}</td>
    </tr>
</table>

<br>

<h3>Menu</h3>



<ul>
    <li>
        <a href="/produk">Lihat Data Produk</a>
    </li>
    <li>
        <a href="/produk/tambah">Input Data Produk</a>
    </li>
</ul>
