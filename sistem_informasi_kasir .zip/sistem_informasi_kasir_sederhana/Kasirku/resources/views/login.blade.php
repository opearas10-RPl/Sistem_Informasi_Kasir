<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - KasirKu</title>
</head>

<body>

    <h1>KasirKu</h1>

    <p>Sistem Informasi Kasir sederhana</p>

    @if(session('success'))
        <p>{{ session('success') }}</p>
    @endif

    @if(session('error'))
        <p>{{ session('error') }}</p>
    @endif

    @if($errors->any())
        <p>{{ $errors->first() }}</p>
    @endif

    <form method="POST" action="/login">
        @csrf

        <div>
            <label>Username</label>
            <br>
            <input
                type="text"
                name="username"
                value="{{ old('username') }}"
                required
            >
        </div>

        <br>

        <div>
            <label>Password</label>
            <br>
            <input
                type="password"
                name="password"
                required
            >
        </div>

        <br>

        <button type="submit">Login</button>
    </form>

    <br>

    <p>
        Belum punya akun?
        <a href="/signup">Sign Up</a>
    </p>

   

</body>
</html>