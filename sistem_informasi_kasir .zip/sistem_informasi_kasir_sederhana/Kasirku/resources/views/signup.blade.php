<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign Up - KasirKu</title>
</head>

<body>

    <h1>KasirKu</h1>
    <h2>Buat Akun</h2>
    <p>Daftar sebagai pengguna kasir</p>

    @if($errors->any())
        <div>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="/signup">
        @csrf

        <div>
            <label>Nama / Username</label>
            <br>
            <input type="text" name="name" value="{{ old('name') }}" required>
        </div>

        <br>

        <div>
            <label>Email</label>
            <br>
            <input type="email" name="email" value="{{ old('email') }}" required>
        </div>

        <br>

        <div>
            <label>Password</label>
            <br>
            <input type="password" name="password" required>
        </div>

        <br>

        <div>
            <label>Konfirmasi Password</label>
            <br>
            <input type="password" name="password_confirmation" required>
        </div>

        <br>

        <button type="submit">Sign Up</button>
    </form>

    <br>

    <a href="/">Kembali ke Login</a>

</body>
</html>