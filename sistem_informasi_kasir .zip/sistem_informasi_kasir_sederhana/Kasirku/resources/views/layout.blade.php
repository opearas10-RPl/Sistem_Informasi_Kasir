
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Sistem Informasi Kasir')</title>
</head>

<body>

    <h1>KasirKu</h1>

    @if (session()->has('user_id'))
        <p>Selamat datang, {{ session('user_name') }}</p>

        <a href="/dashboard">Dashboard</a>
        |
        <a href="/produk">Data Produk</a>
        |
        <a href="/produk/tambah">Input Data Produk</a>
        |
        <a href="/logout">Logout</a>
    @endif

    <hr>

    @if (session('success'))
        <p>{{ session('success') }}</p>
    @endif

    @if (session('error'))
        <p>{{ session('error') }}</p>
    @endif

    @if ($errors->any())
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

    @yield('content')

</body>
</html>
