<h1>Dashboard</h1>

<p>Selamat datang di Sistem Informasi Kasir.</p>

<hr>

<h3>Informasi Produk</h3>

<table border="1" cellpadding="8">  
    <tr>
        <th>Jumlah Produk</th>
        <th>Total Stok</th>
    </tr>
    <tr>
        <td><?php echo e($totalProduk); ?></td>
        <td><?php echo e($totalStok); ?></td>
    </tr>
</table>

<br>

<h3>Menu</h3>



<ul>
    <li>
        <a href="/produk">Lihat Data Produk</a>
    </li>
    <li>
        <a href="/produk/tambah">Input Data Produk</a>
    </li>
</ul>
<?php /**PATH C:\Users\HYPE AMD\Downloads\sistem_informasi_kasir_sederhana\HP-main\resources\views/dashboard.blade.php ENDPATH**/ ?>