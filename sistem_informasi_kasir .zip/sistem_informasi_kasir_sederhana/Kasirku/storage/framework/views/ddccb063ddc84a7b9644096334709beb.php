<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign Up - KasirKu</title>
</head>

<body>

    <h1>KasirKu</h1>
    <h2>Buat Akun</h2>
    <p>Daftar sebagai pengguna kasir</p>

    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="/signup">
        <?php echo csrf_field(); ?>

        <div>
            <label>Nama / Username</label>
            <br>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" required>
        </div>

        <br>

        <div>
            <label>Email</label>
            <br>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required>
        </div>

        <br>

        <div>
            <label>Password</label>
            <br>
            <input type="password" name="password" required>
        </div>

        <br>

        <div>
            <label>Konfirmasi Password</label>
            <br>
            <input type="password" name="password_confirmation" required>
        </div>

        <br>

        <button type="submit">Sign Up</button>
    </form>

    <br>

    <a href="/">Kembali ke Login</a>

</body>
</html><?php /**PATH C:\Users\HYPE AMD\Downloads\sistem_informasi_kasir_sederhana\HP-main\resources\views/signup.blade.php ENDPATH**/ ?>