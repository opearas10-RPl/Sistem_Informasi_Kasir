<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class Kasir extends Controller
{
    private function checkLogin()
    {
        return session()->has('user_id') ? null : redirect('/')->with('error', 'Silakan login terlebih dahulu.');
    }

    public function index()
    {
        if (session()->has('user_id')) {
            return redirect('/dashboard');
        }

        return view('login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        $user = DB::table('users')->where('name', $request->username)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return back()->withInput()->with('error', 'Username atau password salah.');
        }

        session([
            'user_id' => $user->id,
            'user_name' => $user->name,
        ]);

        return redirect('/dashboard');
    }

    public function signup()
    {
        if (session()->has('user_id')) {
            return redirect('/dashboard');
        }

        return view('signup');
    }

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100|unique:users,name',
            'email' => 'required|email|max:150|unique:users,email',
            'password' => 'required|min:6|confirmed',
        ]);

        DB::table('users')->insert([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'level' => 'kasir',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect('/')->with('success', 'Akun berhasil dibuat. Silakan login.');
    }

    public function logout()
    {
        session()->flush();
        return redirect('/')->with('success', 'Berhasil logout.');
    }

    public function dashboard()
    {
        if ($r = $this->checkLogin()) return $r;

        return view('dashboard', [
            'totalProduk' => DB::table('produk')->count(),
            'totalStok' => DB::table('produk')->sum('stok'),
        ]);
    }

    public function produk()
    {
        if ($r = $this->checkLogin()) return $r;

        return view('produk', [
            'produk' => DB::table('produk')->orderByDesc('id')->get(),
        ]);
    }

    public function tambahProduk()
    {
        if ($r = $this->checkLogin()) return $r;
        return view('tambah_produk');
    }

    public function simpanProduk(Request $request)
    {
        if ($r = $this->checkLogin()) return $r;

        $request->validate([
            'kode_produk' => 'required|max:50|unique:produk,kode_produk',
            'nama_produk' => 'required|max:150',
            'kategori' => 'nullable|max:100',
            'harga' => 'required|numeric|min:0',
            'stok' => 'required|integer|min:0',
        ]);

        DB::table('produk')->insert([
            'kode_produk' => $request->kode_produk,
            'nama_produk' => $request->nama_produk,
            'kategori' => $request->kategori,
            'harga' => $request->harga,
            'stok' => $request->stok,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect('/produk')->with('success', 'Data produk berhasil ditambahkan.');
    }

    public function editProduk($id)
    {
        if ($r = $this->checkLogin()) return $r;

        $produk = DB::table('produk')->find($id);
        abort_unless($produk, 404);

        return view('edit_produk', compact('produk'));
    }

    public function updateProduk(Request $request, $id)
    {
        if ($r = $this->checkLogin()) return $r;

        $request->validate([
            'kode_produk' => 'required|max:50|unique:produk,kode_produk,' . $id,
            'nama_produk' => 'required|max:150',
            'kategori' => 'nullable|max:100',
            'harga' => 'required|numeric|min:0',
            'stok' => 'required|integer|min:0',
        ]);

        DB::table('produk')->where('id', $id)->update([
            'kode_produk' => $request->kode_produk,
            'nama_produk' => $request->nama_produk,
            'kategori' => $request->kategori,
            'harga' => $request->harga,
            'stok' => $request->stok,
            'updated_at' => now(),
        ]);

        return redirect('/produk')->with('success', 'Data produk berhasil diperbarui.');
    }

    public function hapusProduk($id)
    {
        if ($r = $this->checkLogin()) return $r;

        DB::table('produk')->where('id', $id)->delete();
        return back()->with('success', 'Data produk berhasil dihapus.');
    }
}
