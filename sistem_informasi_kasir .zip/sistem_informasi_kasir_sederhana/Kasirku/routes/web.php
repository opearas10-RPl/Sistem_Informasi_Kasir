<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Kasir;

Route::get('/', [Kasir::class, 'index']);
Route::post('/login', [Kasir::class, 'login']);
Route::get('/signup', [Kasir::class, 'signup']);
Route::post('/signup', [Kasir::class, 'register']);
Route::get('/logout', [Kasir::class, 'logout']);

Route::get('/dashboard', [Kasir::class, 'dashboard']);
Route::get('/produk', [Kasir::class, 'produk']);
Route::get('/produk/tambah', [Kasir::class, 'tambahProduk']);
Route::post('/produk', [Kasir::class, 'simpanProduk']);
Route::get('/produk/{id}/edit', [Kasir::class, 'editProduk']);
Route::put('/produk/{id}', [Kasir::class, 'updateProduk']);
Route::delete('/produk/{id}', [Kasir::class, 'hapusProduk']);
