# Sistem Informasi Kasir Sederhana

Project Laravel sederhana untuk tugas/latihan, dengan fitur:

- Login
- Sign Up
- Dashboard sederhana
- Input data produk
- Tampil data produk
- Edit data produk
- Hapus data produk
- Logout

## Akun demo
- Username: `admin`
- Password: `admin123`

## Menjalankan project

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
php artisan serve
```

Buka `http://127.0.0.1:8000`.
